# UrbanRoute - Avance 4

Herramienta con interfaz gráfica que modela una red de transporte urbano multimodal como un grafo ponderado
(lista de adyacencia propia) indexado con una tabla hash propia, para detectar subredes aisladas (DFS),
calcular la ruta de menor tiempo (Dijkstra) e identificar hubs de transferencia (grado).

**Integrantes:** (completar nombres)

**Repositorio GitHub:** (completar dirección)

## Cómo ejecutar
Abrir la carpeta en NetBeans (File > Open Project) y pulsar Run. Al iniciar se carga `data/metro_caracas.csv`.
El directorio de trabajo debe ser la carpeta del proyecto (así lo hace NetBeans por defecto).

## Librerías (solo para el dibujo del grafo)
`lib/gs-core-2.0.jar` y `lib/gs-ui-swing-2.0.jar` (GraphStream 2.0). Ya están agregadas al classpath del proyecto
(`nbproject/project.properties`). Si se entrega el ZIP, la carpeta `lib/` debe ir incluida.
Las estructuras de datos y los algoritmos son propios; GraphStream no se usa para ninguno de ellos.

## Estructura
- `Archivos`: `Estacion`, `Arista`, `Hash`, `Grafo`, `Lista`, `ColaPrioridad`, `LectorCSV`, `EscritorCSV`, `ReporteCarga`.
- `Algoritmos`: `Conectividad` (DFS iterativo con pila propia y versión BFS), `RecorridoDFS`, `RutaOptima` (Dijkstra), `Hubs`, `ResultadoRuta`.
- `interfazproyecto`: pantallas (`*Interface`, `Agregar*`, `Eliminar*`, `ConfirmInterface`), `VisorGrafo` (GraphStream),
  `Controlador` (estado compartido y puente con la lógica) y `Dialogos` (mensajes y selección de archivos).

## Flujo de pantallas
Principal -> Mapa -> { Archivo (Cargar / Guardar), Gestión de Red (4 diálogos), Rutas (Calcular / Subredes / Hubs) }.

## DFS en el mapa
En la pantalla del mapa se elige una estación (lista o clic sobre el nodo) y se pulsa "Ejecutar DFS": el recorrido se anima
(visitadas en azul, estación actual en rojo, aristas del árbol DFS resaltadas) y el orden de visita aparece en el cuadro inferior.
"Subredes con DFS" recorre toda la red y colorea cada subred descubierta. La barra de velocidad regula la animación.
